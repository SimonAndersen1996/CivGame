* [OK] Red is the first player in turn
* [OK] Red's city is at (1,1)
* [OK] there is ocean at (1,0) 
* [OK] We have a board that contains a unit at (2,0)
* [OK] cities produce 6 `production' after a round has ended 
* [OK] cities produce 1 ´production focus´ unit when the treasury is above 12 at round end
* [OK] the produced units spawn on red city (1,1)
* [OK] the produced units spawn on their respective city
* [OK] the produced units spawn on adjacent tiles, starting north if occupied
* [OK] cities can change between focus on growth or units
* [OK] cities' population size is always 1 
* [OK] after Red it is Blue that is in turn 
* [OK] Red wins in year 3000 BC 
* [OK] Red's unit attack and destroy Blue's unit 
* [OK] Once all players have had their turn, the round ends
* [OK] The game starts a round 1
* [OK] Players can move units
* [OK] units cannot move over mountain
* [OK] Red cannot move Blue's units
* [OK] Units can only move 1 tile
* [OK] Units cannot be moved for the rest of the turn once moved
* [OK] Cities can be conquered
* [OK] The player who conquered all cities wins
* [OK] Once reaching birth of Christ, change aging from 100 years pr. round to the special sequence
* [OK] Change aging to 50 pr. round in 50AD to 1750AD.
* [OK] Change aging rate from 50 to 25 when reaching 1750AD
* [OK] Change aging rate from 25 to 5 when reaching 1900
* [OK] Change aging rate form 5 to 1 when reaching 1970
* [OK] Games can be change between an AlphaWorld or DeltaWorld
* [OK] ArcherUnit doubles its defense when performing action
* [OK] ArcherUnit can not move, once it has fortified
* [OK] ArcherUnit can move again, but defense is halved when reactivating fortify
* [OK] BigTiddyGothGF can charm units
* [OK] SettlerUnit disappears and is replaced by City of same owner
* [OK] Various testing of Tile generation for DeltaWorld
* [OK] Games can change between different aging and winning strategies
* [OK] The game can count succesfully won attacks
* [OK] The first player to succesfully win 3 attacks wins the game
* [OK] Succesful defenses does not count
* [OK] Red wins through conquering all cities before 20 rounds
* [OK] Red wins through 3 successful attacks after 20 rounds
* [OK] There are desert tiles
* [OK] A sandworm should be on a desert tile
* [OK] A sandworm should be able to move a distance of 2 tiles
* [OK] A sandworm should not be able to move more than 2 tiles
* [OK] A sandworm can only move on desert tiles
* [OK] A sandworm can only be produced on desert tiles
* [OK] A sandworm can devour enemies around it
