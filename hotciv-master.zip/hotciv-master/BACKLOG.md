ITERATION 1
Looking at our ToDo (Mogens), it can be seen which tests / code is available to the customer
We are aware that features, such as unit movement, unit attacks, immovable objects and city treachury / production 
is not in the game yet, but we are working on implementing them as soon as possible.
- Group 7.

ITERATION 2
We have fully completed our AlphaCiv Project. Our testlist is almost complete, what is missing is to have the
restraint that units can only move 1 tile.
- Group 7

ITERATION 3
We have fully completed refactoring, using the compositional design, to fullfill the requirements of Beta-,
Gamma- and DeltaCiv. According to jacocoTestReport, we are missing some tests on branches, but those
are of no importance. Otherwise, we have certainly covered the most important parts of our producktion code.
We have additionally implemented a new type of unit out of pure fun.
Another thing is that we have considered adding test cases to cover NullPointerExceptions, but have not
added them.
- Group 7

ITERATION 5
We have fully implemented both Epsilon- and ZetaCiv. Though we have not implemented EtaCiv, since that is 
optional. If there is anything left to be desired, then it might be code cleaning, though we have done 
as much of it as possible.
- Group 7

ITERATION 6
There are not really any features that are missing in this iteration, except for implementation of 
ProductionStrategy, since we did not do the EtaCiv (optional). All that would be left is some code 
cleaning and some few integration tests.
- Group 7
