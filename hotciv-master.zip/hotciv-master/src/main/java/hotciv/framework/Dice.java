package hotciv.framework;

public interface Dice {

    int rollDie();

}
