package hotciv.framework;

public interface GameStats  {
    int getSuccessfulAttack(Player p);
}
