package hotciv.framework;

public interface ProductionStrategy {

    void produceUnit(Position cityPosition, Game game);

}
