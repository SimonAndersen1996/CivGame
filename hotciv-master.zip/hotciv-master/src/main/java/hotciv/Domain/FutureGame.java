package hotciv.Domain;

public interface FutureGame {

}
