package hotciv.standard;

import hotciv.framework.ActionStrategy;
import hotciv.framework.Game;
import hotciv.framework.Position;
import hotciv.framework.Unit;

public class ActionAlpha implements ActionStrategy {

    @Override
    public void action(Unit unit, Position position, Game game) {
        //Do nothing at all
    }

}
